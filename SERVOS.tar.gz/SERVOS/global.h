//global variables

int YAW=0;
int PITCH=1;
int ROLL=2;

int DIM=3;
